﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; // variaveis globais
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close(); //encerra
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out numero1) &&
                double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 - numero2;
                textBox3.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Numero Inválido");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out numero1) &&
                double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 * numero2;
                textBox3.Text = resultado.ToString();
            }
            else
            {
                MessageBox.Show("Numero Inválido");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out numero1) &&
                double.TryParse(textBox2.Text, out numero2))
            {
                if (numero2 == 0)
                {
                    MessageBox.Show("Não pode dividir por zero!!!");
                }
                else
                {
                    resultado = numero1 / numero2;
                    textBox3.Text = resultado.ToString();
                }
            }
            else
            {
                MessageBox.Show("Numero Inválido");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Text = "";       //modos de limpar
            textBox3.Text = null;

            textBox1.Focus();         //foca nele
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out numero1) &&  
                double.TryParse(textBox2.Text, out numero2))
            {
                resultado = numero1 + numero2;        //tryparse p aceitar so numero
                textBox3.Text = resultado.ToString(); // muda p string
            }
            else
            {
                MessageBox.Show("Numero Inválido");
            }
        }
    }
}
